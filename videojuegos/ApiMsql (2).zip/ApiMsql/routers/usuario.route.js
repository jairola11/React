import {Router} from "express";


import {guardarUsuario, listarUsuario,buscarUsuario,eliminarUsuario,actualizarUsuario} from '../controller/usuario.controller.js';

import {validarToken} from '../controller/autenticacion.controller.js';
import {validatorUser} from '../validator/validator.js';
const usuarioRoute = Router();

usuarioRoute.get('/listar',listarUsuario);
usuarioRoute.get('/buscar/:id',buscarUsuario);
usuarioRoute.post('/registrar',validarToken,validatorUser,guardarUsuario);
usuarioRoute.delete('/eliminar/:id',validarToken,eliminarUsuario);

usuarioRoute.put('/actualizar/:id',validarToken,validatorUser,actualizarUsuario);

export default usuarioRoute;


